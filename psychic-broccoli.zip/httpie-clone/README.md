# 🥦 Psychic Broccoli — A Tauri HTTP Client with .http File Support

A lightweight, fast HTTP client built with **Tauri v2 + Svelte + TypeScript**.
Reads and writes `.http` files compatible with Visual Studio, VS Code REST Client, and JetBrains HTTP Client.

## Quick Start

### 1. Scaffold the Tauri project

```bash
npm create tauri-app@latest volt -- --template svelte-ts
cd volt
pnpm install
```

### 2. Copy the source files

Replace the generated `src/` directory contents with the files from this project:

```
src/
├── App.svelte                         ← Main app layout + env integration
├── main.ts                            ← Svelte entry point
├── lib/
│   ├── types.ts                       ← TypeScript interfaces (full spec)
│   ├── parser.ts                      ← .http parser, serializer, variable engine
│   └── stores.ts                      ← Svelte stores (file, env, named results)
└── components/
    ├── Sidebar.svelte                 ← Request list panel
    ├── RequestEditor.svelte           ← URL bar, headers, body, @name editor
    ├── ResponseViewer.svelte          ← Response display panel
    ├── EnvironmentSelector.svelte     ← Environment dropdown in titlebar
    └── VariablesPanel.svelte          ← Sidebar panel showing resolved variables
```

Also copy these to the project root (alongside the `.http` files you work with):

```
http-client.env.json                   ← Shared environment definitions
http-client.env.json.user              ← User-specific overrides (gitignored)
example.http                           ← Comprehensive example file
```

### 3. Install Tauri plugins

```bash
pnpm tauri add fs
pnpm tauri add dialog
pnpm tauri add http
```

### 4. Configure plugin permissions

In `src-tauri/capabilities/default.json`:

```json
{
  "permissions": [
    "core:default",
    "dialog:default",
    "fs:default",
    "fs:allow-read-text-file",
    "fs:allow-write-text-file",
    "http:default",
    "http:allow-fetch"
  ]
}
```

### 5. Uncomment Tauri imports

In `src/App.svelte`, swap the demo code blocks with the Tauri-native versions.
Each integration point is marked with `// Tauri version (uncomment when ready)`.

### 6. Run

```bash
pnpm tauri dev
```

---

## .http File Syntax — Full Spec Coverage

This parser implements the complete Visual Studio .http file specification
as documented at https://learn.microsoft.com/en-us/aspnet/core/test/http-files

### Requests

```http
GET https://api.example.com/users
```

Full format: `METHOD URL [HTTP/version]`. Supported methods:
GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS, TRACE, CONNECT.

### Request separators

```http
### Optional request name
GET https://api.example.com/users

###
GET https://api.example.com/posts
```

### Comments

```http
# This is a comment
// This is also a comment
GET https://api.example.com/users
```

### Headers

Headers go immediately after the request line with no blank line between:

```http
GET https://api.example.com/users
Authorization: Bearer my-token
Accept: application/json
Cache-Control: no-cache
```

### Request body

A blank line separates headers from body:

```http
POST https://api.example.com/users
Content-Type: application/json

{
  "name": "Jane",
  "email": "jane@example.com"
}
```

### File-level variables

```http
@hostname = localhost
@port = 44320
@host = {{hostname}}:{{port}}

GET https://{{host}}/api/users
```

Variables can reference earlier variables. File-level variables have the
**highest priority** — they override environment file values.

---

## Environment System

### http-client.env.json

Place this file in the same directory as your `.http` file:

```json
{
  "$shared": {
    "BaseUrl": "https://localhost:5000",
    "ContentType": "application/json"
  },
  "dev": {
    "Token": "dev-token-123"
  },
  "staging": {
    "BaseUrl": "https://staging.api.com",
    "Token": "staging-token-789"
  }
}
```

**`$shared`** — Variables available to ALL environments as defaults.
Environment-specific values override `$shared`.

### http-client.env.json.user

User-specific overrides that should **not** be committed to source control:

```json
{
  "dev": {
    "Token": "my-personal-dev-token"
  }
}
```

### Variable resolution priority

From highest to lowest priority:

| Priority | Source | Example |
|----------|--------|---------|
| 1 | `.http` file `@variable` | `@BaseUrl = http://localhost:3000` |
| 2 | `.user` env-specific | `http-client.env.json.user` → `dev.Token` |
| 3 | env file env-specific | `http-client.env.json` → `dev.Token` |
| 4 | `.user` `$shared` | `http-client.env.json.user` → `$shared.X` |
| 5 | env file `$shared` | `http-client.env.json` → `$shared.BaseUrl` |

### Provider-based variables (placeholder)

The spec supports Azure Key Vault, ASP.NET User Secrets, and DPAPI encryption.
These are parsed but require platform-specific APIs to resolve at runtime:

```json
{
  "dev": {
    "ApiKey": {
      "provider": "AspnetUserSecrets",
      "secretName": "config:ApiKey"
    }
  }
}
```

---

## Request Variables (Chaining)

Name a request using `# @name` or `// @name`:

```http
# @name login
POST https://api.example.com/auth/token
Content-Type: application/json

{
  "username": "admin",
  "password": "secret"
}

###

GET https://api.example.com/protected
Authorization: Bearer {{login.response.body.$.token}}
```

### Reference syntax

```
{{requestName.response.body.*}}              — entire body
{{requestName.response.body.$.token}}        — JSONPath
{{requestName.response.body.$.data[0].id}}   — JSONPath with array index
{{requestName.response.headers.Location}}    — response header (case-insensitive)
```

The named request must be sent first to populate its response.

---

## Dynamic Variables

Built-in variables that generate values at send time:

### `$randomInt`

```http
GET https://api.example.com/posts/{{$randomInt 1 100}}
```

Default range: 0–1000. Optional `[min max]` arguments.

### `$timestamp`

```http
X-Timestamp: {{$timestamp}}
X-Tomorrow: {{$timestamp 1 d}}
```

Unix epoch seconds in UTC. Supports offset.

### `$datetime` and `$localDatetime`

```http
X-ISO: {{$datetime iso8601}}
X-RFC: {{$datetime rfc1123}}
X-Custom: {{$datetime "dd-MM-yyyy"}}
X-Local: {{$localDatetime iso8601}}
X-Future: {{$datetime iso8601 1 d}}
X-Past: {{$datetime "dd-MM-yyyy" -1 y}}
```

| Format | Output |
|--------|--------|
| `iso8601` | `2025-01-17T22:59:55.534Z` |
| `rfc1123` | `Wed, 17 Jan 2025 22:59:55 GMT` |
| `"dd-MM-yyyy"` | `17-01-2025` |

### Offset units

| Unit | Meaning |
|------|---------|
| `ms` | Milliseconds |
| `s` | Seconds |
| `m` | Minutes |
| `h` | Hours |
| `d` | Days |
| `w` | Weeks |
| `M` | Months |
| `y` | Years |

### `$processEnv` and `$dotenv`

```http
X-User: {{$processEnv USERNAME}}
X-Key: {{$dotenv API_KEY}}
```

`$processEnv` reads OS environment variables (requires Tauri env API).
`$dotenv` reads from a `.env` file in the project directory.

---

## Features

- **Full .http spec** — comments, separators, variables, body, all 9 methods
- **Environment system** — `http-client.env.json` + `.user` overrides + `$shared`
- **Environment selector** — dropdown in the title bar
- **Request variable chaining** — `# @name` + `{{name.response.body.$.path}}`
- **Dynamic variables** — `$randomInt`, `$datetime`, `$timestamp`, `$localDatetime`
- **Variable resolution panel** — see all resolved variables with their source
- **Read/write .http files** — native file dialogs via Tauri
- **No CORS** — Tauri HTTP plugin bypasses browser restrictions
- **Keyboard shortcut** — Ctrl+Enter to send

---

## Roadmap

- [ ] Syntax highlighting in body editor (CodeMirror / Monaco)
- [ ] Auto-discover `http-client.env.json` from .http file directory
- [ ] `.env` file support for `$dotenv`
- [ ] `$processEnv` via Tauri environment API
- [ ] XPath support for XML response bodies
- [ ] Request history / timeline
- [ ] Response diff between runs
- [ ] Import from Postman / Insomnia collections
- [ ] Auto-complete for common headers and variables
- [ ] Cookie jar management
- [ ] File watcher — auto-reload on disk change
- [ ] Multiple tabs for multiple .http files
- [ ] Provider variable resolution (Azure Key Vault, DPAPI, User Secrets)
