<script lang="ts">
  import type { HttpResponse } from '../lib/types';

  export let response: HttpResponse | null = null;
  export let loading: boolean = false;

  let activeTab: 'body' | 'headers' = 'body';

  function getStatusClass(status: number): string {
    if (status >= 200 && status < 300) return 'status-success';
    if (status >= 300 && status < 400) return 'status-redirect';
    if (status >= 400 && status < 500) return 'status-client-error';
    if (status >= 500) return 'status-server-error';
    return 'status-error';
  }

  function formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  function formatBody(body: string): string {
    try {
      return JSON.stringify(JSON.parse(body), null, 2);
    } catch {
      return body;
    }
  }

  function isJson(body: string): boolean {
    try {
      JSON.parse(body);
      return true;
    } catch {
      return false;
    }
  }
</script>

<div class="response-viewer">
  {#if loading}
    <div class="empty-state">
      <div class="loading-indicator">
        <div class="pulse-ring"></div>
        <div class="pulse-ring delay"></div>
        <span class="loading-icon">🥦</span>
      </div>
      <span class="empty-text">Sending request...</span>
    </div>
  {:else if !response}
    <div class="empty-state">
      <span class="empty-icon">↗</span>
      <span class="empty-text">Send a request to see the response</span>
      <span class="empty-hint">Use the Send button or Ctrl+Enter</span>
    </div>
  {:else}
    <!-- Status Bar -->
    <div class="status-bar">
      <div class="status-info">
        <span class="status-badge {getStatusClass(response.status)}">
          {response.status}
        </span>
        <span class="status-text">{response.statusText}</span>
      </div>
      <div class="meta-chips">
        <span class="chip">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <circle cx="6" cy="6" r="5" stroke="currentColor" stroke-width="1.2"/>
            <path d="M6 3v3.5l2.5 1.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/>
          </svg>
          {response.time} ms
        </span>
        <span class="chip">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M2 10V4l4-2 4 2v6l-4 2-4-2z" stroke="currentColor" stroke-width="1.2"/>
          </svg>
          {formatSize(response.size)}
        </span>
      </div>
    </div>

    <!-- Response Tabs -->
    <div class="tabs">
      <button
        class="tab"
        class:active={activeTab === 'body'}
        on:click={() => activeTab = 'body'}
      >
        Body
        {#if isJson(response.body)}
          <span class="tab-badge">JSON</span>
        {/if}
      </button>
      <button
        class="tab"
        class:active={activeTab === 'headers'}
        on:click={() => activeTab = 'headers'}
      >
        Headers
        <span class="tab-count">{Object.keys(response.headers).length}</span>
      </button>
    </div>

    <!-- Content -->
    <div class="content">
      {#if activeTab === 'body'}
        <pre class="body-output" class:json={isJson(response.body)}>{formatBody(response.body)}</pre>
      {:else}
        <div class="headers-table">
          {#each Object.entries(response.headers) as [key, value]}
            <div class="header-entry">
              <span class="hdr-key">{key}</span>
              <span class="hdr-value">{value}</span>
            </div>
          {/each}
          {#if Object.keys(response.headers).length === 0}
            <div class="no-headers">No headers returned</div>
          {/if}
        </div>
      {/if}
    </div>
  {/if}
</div>

<style>
  .response-viewer {
    display: flex;
    flex-direction: column;
    height: 100%;
    padding: 16px;
  }

  /* Empty State */
  .empty-state {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    color: #444;
  }
  .empty-icon {
    font-size: 40px;
    opacity: 0.3;
    margin-bottom: 8px;
  }
  .empty-text {
    font-size: 14px;
    color: #555;
  }
  .empty-hint {
    font-size: 11px;
    color: #333;
  }

  /* Loading */
  .loading-indicator {
    position: relative;
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 12px;
  }
  .pulse-ring {
    position: absolute;
    width: 100%;
    height: 100%;
    border: 2px solid #F4A623;
    border-radius: 50%;
    animation: pulse-out 1.5s ease-out infinite;
  }
  .pulse-ring.delay {
    animation-delay: 0.3s;
  }
  @keyframes pulse-out {
    0% { transform: scale(0.5); opacity: 1; }
    100% { transform: scale(1.4); opacity: 0; }
  }
  .loading-icon {
    font-size: 20px;
    z-index: 1;
    animation: pulse-glow 1s ease-in-out infinite alternate;
  }
  @keyframes pulse-glow {
    0% { opacity: 0.5; }
    100% { opacity: 1; }
  }

  /* Status Bar */
  .status-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }
  .status-info {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .status-badge {
    font-size: 14px;
    font-weight: 700;
    padding: 4px 12px;
    border-radius: 6px;
    letter-spacing: 0.3px;
  }
  .status-success {
    background: #98C37920;
    color: #98C379;
  }
  .status-redirect {
    background: #61AFEF20;
    color: #61AFEF;
  }
  .status-client-error {
    background: #E5C07B20;
    color: #E5C07B;
  }
  .status-server-error {
    background: #E06C7520;
    color: #E06C75;
  }
  .status-error {
    background: #E06C7520;
    color: #E06C75;
  }
  .status-text {
    font-size: 13px;
    color: #888;
  }

  .meta-chips {
    display: flex;
    gap: 8px;
  }
  .chip {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 11px;
    color: #777;
    padding: 4px 10px;
    background: #16161E;
    border-radius: 6px;
  }

  /* Tabs */
  .tabs {
    display: flex;
    gap: 2px;
    border-bottom: 1px solid #1E1E28;
    margin-bottom: 12px;
  }
  .tab {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border: none;
    background: transparent;
    color: #666;
    font-family: inherit;
    font-size: 12px;
    cursor: pointer;
    border-bottom: 2px solid transparent;
    transition: all 0.15s;
    margin-bottom: -1px;
  }
  .tab:hover { color: #999; }
  .tab.active {
    color: #E8E6E3;
    border-bottom-color: #F4A623;
  }
  .tab-badge {
    font-size: 9px;
    font-weight: 600;
    padding: 2px 6px;
    border-radius: 4px;
    background: #61AFEF20;
    color: #61AFEF;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  .tab-count {
    background: #2A2A38;
    color: #888;
    font-size: 10px;
    padding: 1px 6px;
    border-radius: 10px;
  }

  /* Content */
  .content {
    flex: 1;
    overflow: auto;
    min-height: 0;
  }

  .body-output {
    padding: 16px;
    background: #111118;
    border: 1px solid #1E1E28;
    border-radius: 8px;
    font-family: inherit;
    font-size: 12.5px;
    line-height: 1.65;
    color: #C8C5BE;
    overflow: auto;
    white-space: pre-wrap;
    word-break: break-word;
    max-height: 100%;
  }
  .body-output.json {
    color: #ABB2BF;
  }

  /* Headers Table */
  .headers-table {
    display: flex;
    flex-direction: column;
    gap: 1px;
    background: #1E1E28;
    border-radius: 8px;
    overflow: hidden;
  }
  .header-entry {
    display: grid;
    grid-template-columns: 200px 1fr;
    background: #111118;
    padding: 10px 14px;
  }
  .hdr-key {
    font-size: 12px;
    font-weight: 600;
    color: #E5C07B;
  }
  .hdr-value {
    font-size: 12px;
    color: #ABB2BF;
    word-break: break-all;
  }
  .no-headers {
    padding: 20px;
    text-align: center;
    color: #444;
    font-size: 12px;
    background: #111118;
  }
</style>
