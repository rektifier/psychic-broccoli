<script lang="ts">
  import { createEventDispatcher } from 'svelte';
  import type { HttpRequest, HttpMethod, HttpHeader, Variable, NamedRequestResult } from '../lib/types';
  import DependencyBar from './DependencyBar.svelte';
  import VariablePicker from './VariablePicker.svelte';

  export let request: HttpRequest;
  export let loading: boolean = false;
  export let resolvedUrl: string = '';
  export let dirty: boolean = false;
  export let fileVariables: Variable[] = [];
  export let envVariables: Record<string, string> = {};
  export let namedResults: Record<string, NamedRequestResult> = {};

  const dispatch = createEventDispatcher();

  const methods: HttpMethod[] = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS', 'TRACE', 'CONNECT'];
  const methodColors: Record<string, string> = {
    GET: '#61AFEF',
    POST: '#98C379',
    PUT: '#E5C07B',
    PATCH: '#D19A66',
    DELETE: '#E06C75',
    HEAD: '#C678DD',
    OPTIONS: '#56B6C2',
    TRACE: '#ABB2BF',
    CONNECT: '#E06C75',
  };

  let headersOpen = true;
  let showPicker = false;
  let pickerTarget: 'url' | 'headerKey' | 'headerValue' | 'body' | null = null;
  let pickerHeaderIndex: number = -1;

  function update(changes: Partial<HttpRequest>) {
    dispatch('update', { ...request, ...changes });
  }

  function send() {
    dispatch('send', request);
  }

  function addHeader() {
    update({ headers: [...request.headers, { key: '', value: '', enabled: true }] });
  }

  function updateHeader(index: number, changes: Partial<HttpHeader>) {
    const headers = [...request.headers];
    headers[index] = { ...headers[index], ...changes };
    update({ headers });
  }

  function removeHeader(index: number) {
    update({ headers: request.headers.filter((_, i) => i !== index) });
  }

  function handleKeydown(e: KeyboardEvent) {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      send();
    }
  }

  // Combine all request text for dependency scanning
  $: requestText = [
    request.url,
    ...request.headers.map(h => `${h.key}: ${h.value}`),
    request.body,
  ].join('\n');

  function openPicker(target: 'url' | 'body', headerIndex?: number) {
    pickerTarget = target;
    pickerHeaderIndex = headerIndex ?? -1;
    showPicker = true;
  }

  function handlePickerInsert(e: CustomEvent<string>) {
    const value = e.detail;
    showPicker = false;
    if (pickerTarget === 'url') {
      update({ url: request.url + value });
    } else if (pickerTarget === 'body') {
      update({ body: request.body + value });
    } else if (pickerTarget === 'headerValue' && pickerHeaderIndex >= 0) {
      const headers = [...request.headers];
      headers[pickerHeaderIndex] = { ...headers[pickerHeaderIndex], value: headers[pickerHeaderIndex].value + value };
      update({ headers });
    }
  }
</script>

<div class="editor" on:keydown={handleKeydown}>
  <!-- Request Name -->
  <div class="name-row">
    <input
      class="name-input"
      type="text"
      value={request.name}
      on:input={(e) => update({ name: e.currentTarget.value })}
      placeholder="Request name"
    />
    {#if dirty}
      <button class="btn-save-file" on:click={() => dispatch('save')}>
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
          <path d="M12 14H4a1 1 0 01-1-1V3a1 1 0 011-1h6l3 3v8a1 1 0 01-1 1z" stroke="currentColor" stroke-width="1.5"/>
          <path d="M5 14v-4h6v4M5 2v3h4" stroke="currentColor" stroke-width="1.5"/>
        </svg>
        Save
      </button>
    {/if}
  </div>

  <!-- URL Bar -->
  <div class="url-bar">
    <select
      class="method-select"
      value={request.method}
      style="color: {methodColors[request.method]}"
      on:change={(e) => update({ method: e.currentTarget.value as HttpMethod })}
    >
      {#each methods as method}
        <option value={method} style="color: {methodColors[method]}">{method}</option>
      {/each}
    </select>

    <input
      class="url-input"
      type="text"
      value={request.url}
      on:input={(e) => update({ url: e.currentTarget.value })}
      placeholder="https://api.example.com/endpoint"
      spellcheck="false"
    />

    <button
      class="btn-send"
      on:click={send}
      disabled={loading}
      class:loading
    >
      {#if loading}
        <span class="spinner"></span>
      {:else}
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M2 7h10M8 3l4 4-4 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Send
      {/if}
    </button>
  </div>

  {#if resolvedUrl}
    <div class="resolved-url">
      <span class="resolved-arrow">→</span>
      <span class="resolved-value">{resolvedUrl}</span>
    </div>
  {/if}

  <!-- Dependency bar -->
  <DependencyBar
    {requestText}
    {namedResults}
    on:runAll
  />

  <!-- Headers (collapsible) -->
  <div class="section">
    <button class="section-toggle" on:click={() => headersOpen = !headersOpen}>
      <span class="chevron" class:open={headersOpen}>
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          <path d="M3 1.5l4 3.5-4 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </span>
      Headers
      {#if request.headers.length > 0}
        <span class="section-count">{request.headers.filter(h => h.enabled).length}</span>
      {/if}
    </button>
    {#if headersOpen}
      <div class="headers-section">
        {#each request.headers as header, i}
          <div class="header-row">
            <input type="checkbox" class="header-toggle" checked={header.enabled}
              on:change={(e) => updateHeader(i, { enabled: e.currentTarget.checked })} />
            <input class="header-key" type="text" value={header.key}
              on:input={(e) => updateHeader(i, { key: e.currentTarget.value })} placeholder="Header name" spellcheck="false" />
            <input class="header-value" type="text" value={header.value}
              on:input={(e) => updateHeader(i, { value: e.currentTarget.value })} placeholder="Value" spellcheck="false" />
            <button class="btn-insert" on:click={() => openPicker('headerValue', i)} title="Insert variable">
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                <path d="M2 4c0-1.1.9-2 2-2M2 8c0 1.1.9 2 2 2M10 4c0-1.1-.9-2-2-2M10 8c0 1.1-.9 2-2 2M6 3v6M4 6h4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/>
              </svg>
            </button>
            <button class="btn-remove" on:click={() => removeHeader(i)}>×</button>
          </div>
        {/each}
        <button class="btn-add-header" on:click={addHeader}>+ Add Header</button>
      </div>
    {/if}
  </div>

  <!-- Body -->
  <div class="section body-grow">
    <div class="section-row">
      <span class="section-label">Body</span>
      <button class="btn-insert" on:click={() => openPicker('body')} title="Insert variable">
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <path d="M2 4c0-1.1.9-2 2-2M2 8c0 1.1.9 2 2 2M10 4c0-1.1-.9-2-2-2M10 8c0 1.1-.9 2-2 2M6 3v6M4 6h4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/>
        </svg>
      </button>
    </div>
    <textarea
      class="body-editor"
      value={request.body}
      on:input={(e) => update({ body: e.currentTarget.value })}
      placeholder={'{"key": "value"}'}
      spellcheck="false"
    ></textarea>
  </div>

  <div class="keyboard-hint">
    <kbd>Ctrl</kbd>+<kbd>Enter</kbd> to send
  </div>
</div>

<!-- Variable picker modal -->
<VariablePicker
  visible={showPicker}
  {fileVariables}
  {envVariables}
  {namedResults}
  on:insert={handlePickerInsert}
  on:close={() => showPicker = false}
/>

<style>
  .editor {
    display: flex;
    flex-direction: column;
    height: 100%;
    padding: 16px;
    gap: 12px;
  }

  .name-row {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .name-input {
    flex: 1;
    padding: 6px 0;
    border: none;
    background: transparent;
    color: #E8E6E3;
    font-family: inherit;
    font-size: 16px;
    font-weight: 600;
    outline: none;
    border-bottom: 1px solid transparent;
    transition: border-color 0.15s;
    min-width: 0;
  }
  .name-input:focus {
    border-bottom-color: #333;
  }
  .btn-save-file {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 5px 14px;
    border: none;
    border-radius: 6px;
    background: #98C379;
    color: #0C0C10;
    font-family: inherit;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    flex-shrink: 0;
    transition: background 0.15s;
  }
  .btn-save-file:hover {
    background: #A9D48A;
  }

  .url-bar {
    display: flex;
    gap: 0;
    background: #16161E;
    border: 1px solid #2A2A38;
    border-radius: 10px;
    overflow: hidden;
    transition: border-color 0.15s;
  }
  .url-bar:focus-within {
    border-color: #F4A623;
  }

  .method-select {
    padding: 12px 14px;
    border: none;
    border-right: 1px solid #2A2A38;
    background: #111118;
    color: #61AFEF;
    font-family: inherit;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    outline: none;
    min-width: 90px;
  }
  .method-select option {
    background: #16161E;
  }

  .url-input {
    flex: 1;
    padding: 12px 14px;
    border: none;
    background: transparent;
    color: #E8E6E3;
    font-family: inherit;
    font-size: 13px;
    outline: none;
  }
  .url-input::placeholder {
    color: #444;
  }

  .btn-send {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 10px 20px;
    border: none;
    background: #F4A623;
    color: #0C0C10;
    font-family: inherit;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.15s;
    letter-spacing: 0.3px;
  }
  .btn-send:hover {
    background: #FFB940;
  }
  .btn-send:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  .btn-send.loading {
    padding: 10px 28px;
  }

  .spinner {
    width: 16px;
    height: 16px;
    border: 2px solid #0C0C1040;
    border-top-color: #0C0C10;
    border-radius: 50%;
    animation: spin 0.6s linear infinite;
  }
  @keyframes spin {
    to { transform: rotate(360deg); }
  }

  /* Resolved URL */
  .resolved-url {
    font-size: 11px;
    padding: 0 2px;
    margin-top: -4px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .resolved-arrow { color: #444; }
  .resolved-value { color: #98C379; }

  /* Sections */
  .section {
    border-top: 1px solid #1E1E28;
    padding-top: 4px;
  }
  .section-toggle {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    padding: 8px 0;
    border: none;
    background: transparent;
    color: #999;
    font-family: inherit;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    text-align: left;
  }
  .section-toggle:hover { color: #E8E6E3; }
  .chevron {
    display: inline-flex;
    align-items: center;
    color: #555;
    transition: transform 0.15s;
  }
  .chevron.open { transform: rotate(90deg); }
  .section-count {
    background: #2A2A38;
    color: #888;
    font-size: 10px;
    padding: 1px 6px;
    border-radius: 10px;
  }
  .section-label {
    display: block;
    font-size: 12px;
    font-weight: 500;
    color: #999;
    padding: 8px 0 6px;
  }
  .section-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .btn-insert {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 24px; height: 24px;
    border: 1px solid #2A2A38;
    border-radius: 4px;
    background: transparent;
    color: #555;
    cursor: pointer;
    flex-shrink: 0;
    padding: 0;
    transition: all 0.15s;
  }
  .btn-insert:hover {
    border-color: #E5C07B;
    color: #E5C07B;
    background: #E5C07B10;
  }
  .body-grow {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;
    border-top: 1px solid #1E1E28;
  }

  /* Headers */
  .headers-section {
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding-bottom: 8px;
  }
  .header-row {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .header-toggle {
    accent-color: #F4A623;
    flex-shrink: 0;
    cursor: pointer;
  }
  .header-key, .header-value {
    flex: 1;
    padding: 8px 10px;
    border: 1px solid #1E1E28;
    border-radius: 6px;
    background: #111118;
    color: #C8C5BE;
    font-family: inherit;
    font-size: 12px;
    outline: none;
    transition: border-color 0.15s;
  }
  .header-key:focus, .header-value:focus { border-color: #3A3A4A; }
  .header-key::placeholder, .header-value::placeholder { color: #444; }
  .header-key { color: #E5C07B; max-width: 180px; }

  .btn-remove {
    display: flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border: none; border-radius: 6px;
    background: transparent; color: #555; font-size: 16px;
    cursor: pointer; flex-shrink: 0; transition: all 0.15s;
  }
  .btn-remove:hover { background: #E06C7520; color: #E06C75; }

  .btn-add-header {
    padding: 8px 14px; border: 1px dashed #2A2A38; border-radius: 6px;
    background: transparent; color: #555; font-family: inherit;
    font-size: 12px; cursor: pointer; transition: all 0.15s;
    margin-top: 4px; align-self: flex-start;
  }
  .btn-add-header:hover { border-color: #F4A623; color: #F4A623; }

  /* Body */
  .body-editor {
    width: 100%;
    flex: 1;
    min-height: 120px;
    padding: 14px;
    border: 1px solid #1E1E28;
    border-radius: 8px;
    background: #111118;
    color: #C8C5BE;
    font-family: inherit;
    font-size: 13px;
    line-height: 1.6;
    outline: none;
    resize: none;
    transition: border-color 0.15s;
  }
  .body-editor:focus { border-color: #3A3A4A; }
  .body-editor::placeholder { color: #333; }

  .keyboard-hint {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 11px;
    color: #444;
    padding-top: 4px;
  }
  .keyboard-hint kbd {
    padding: 1px 6px;
    border: 1px solid #2A2A38;
    border-radius: 4px;
    background: #16161E;
    font-family: inherit;
    font-size: 10px;
  }
</style>
