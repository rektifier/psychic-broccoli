<script lang="ts">
  import { createEventDispatcher } from 'svelte';
  import type { EnvironmentFile } from '../lib/types';

  export let envFile: EnvironmentFile;
  export let activeEnv: string;

  const dispatch = createEventDispatcher();

  // Local editing state — independent from sidebar's active env
  let editingEnv = activeEnv;

  // Get the variables for the editing environment as an editable array
  $: envVars = buildVarList(envFile, editingEnv);

  interface EnvVar {
    key: string;
    value: string;
    enabled: boolean;
  }

  function buildVarList(ef: EnvironmentFile, env: string): EnvVar[] {
    const vars = ef?.[env];
    if (!vars) return [];
    return Object.entries(vars).map(([key, value]) => ({
      key,
      value: typeof value === 'string' ? value : JSON.stringify(value),
      enabled: true,
    }));
  }

  // Environments list (excluding $shared)
  $: envNames = Object.keys(envFile || {}).filter(k => k !== '$shared');

  // Editing state
  let renaming = false;
  let renameValue = '';

  function startRename() {
    renameValue = editingEnv;
    renaming = true;
  }

  function confirmRename() {
    const newName = renameValue.trim();
    if (!newName || newName === editingEnv || envFile[newName]) {
      renaming = false;
      return;
    }
    const updated = { ...envFile };
    updated[newName] = updated[editingEnv];
    delete updated[editingEnv];
    dispatch('update', updated);
    // If the renamed env was the active one, update the sidebar too
    if (editingEnv === activeEnv) {
      dispatch('changeEnv', newName);
    }
    editingEnv = newName;
    renaming = false;
  }

  function deleteEnvironment() {
    if (envNames.length <= 1) return;
    const updated = { ...envFile };
    delete updated[editingEnv];
    dispatch('update', updated);
    const remaining = Object.keys(updated).filter(k => k !== '$shared');
    // If the deleted env was the active one, update the sidebar too
    if (editingEnv === activeEnv) {
      dispatch('changeEnv', remaining[0] || null);
    }
    editingEnv = remaining[0] || '';
  }

  function updateVariable(index: number, field: 'key' | 'value', newVal: string) {
    const vars = [...envVars];
    vars[index] = { ...vars[index], [field]: newVal };
    saveVars(vars);
  }

  function toggleVariable(index: number) {
    const vars = [...envVars];
    vars[index] = { ...vars[index], enabled: !vars[index].enabled };
    // For now we just remove disabled vars from the file
    // (the .http spec doesn't have a concept of disabled env vars)
    saveVars(vars);
  }

  function removeVariable(index: number) {
    const vars = envVars.filter((_, i) => i !== index);
    saveVars(vars);
  }

  function addVariable() {
    const vars = [...envVars, { key: '', value: '', enabled: true }];
    saveVars(vars);
  }

  function saveVars(vars: EnvVar[]) {
    const updated = { ...envFile };
    const envData: Record<string, string> = {};
    for (const v of vars) {
      if (v.key.trim()) {
        envData[v.key.trim()] = v.value;
      }
    }
    updated[editingEnv] = envData;
    dispatch('update', updated);
  }

  function close() {
    dispatch('close');
  }
</script>

<div class="env-editor">
  <!-- Header -->
  <div class="editor-header">
    <div class="header-left">
      <span class="env-dot" class:active-dot={editingEnv === activeEnv}></span>
      {#if renaming}
        <input
          class="rename-input"
          bind:value={renameValue}
          on:keydown={(e) => { if (e.key === 'Enter') confirmRename(); if (e.key === 'Escape') renaming = false; }}
          on:blur={confirmRename}
          autofocus
        />
      {:else}
        <span class="env-name">{editingEnv}</span>
      {/if}
      <span class="var-count">{envVars.length} variable{envVars.length !== 1 ? 's' : ''}</span>
      {#if editingEnv === activeEnv}
        <span class="active-badge">active</span>
      {/if}
    </div>
    <div class="header-actions">
      <button class="btn-action" on:click={startRename}>Rename</button>
      {#if envNames.length > 1}
        <button class="btn-action btn-danger" on:click={deleteEnvironment}>Delete</button>
      {/if}
      <button class="btn-done" on:click={close}>Save</button>
    </div>
  </div>

  <!-- Env tabs -->
  <div class="env-tabs">
    {#each envNames as env}
      <button
        class="env-tab"
        class:active={env === editingEnv}
        on:click={() => editingEnv = env}
      >{env}{env === activeEnv ? ' ✓' : ''}</button>
    {/each}
  </div>

  <!-- Column headers -->
  <div class="col-headers">
    <span class="col-check"></span>
    <span class="col-key">Variable</span>
    <span class="col-value">Value</span>
    <span class="col-del"></span>
  </div>

  <!-- Variable rows -->
  <div class="var-rows">
    {#each envVars as v, i}
      <div class="var-row" class:disabled={!v.enabled}>
        <input
          type="checkbox"
          class="var-check"
          checked={v.enabled}
          on:change={() => toggleVariable(i)}
        />
        <input
          class="var-key"
          value={v.key}
          on:input={(e) => updateVariable(i, 'key', e.currentTarget.value)}
          placeholder="variableName"
          spellcheck="false"
        />
        <input
          class="var-value"
          value={v.value}
          on:input={(e) => updateVariable(i, 'value', e.currentTarget.value)}
          placeholder="value"
          spellcheck="false"
        />
        <button class="btn-remove" on:click={() => removeVariable(i)}>×</button>
      </div>
    {/each}

    <button class="btn-add-var" on:click={addVariable}>
      + Add variable
    </button>
  </div>

  <!-- Footer hint -->
  <div class="editor-footer">
    <span>
      Saved to <code>http-client.env.json</code> in workspace root.
      Use as <code>{'{{variableName}}'}</code> in .http files.
    </span>
  </div>
</div>

<style>
  .env-editor {
    display: flex;
    flex-direction: column;
    height: 100%;
    padding: 20px 24px;
    overflow: auto;
  }

  /* Header */
  .editor-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
  }
  .header-left {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .env-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #555;
    flex-shrink: 0;
  }
  .env-dot.active-dot {
    background: #98C379;
  }
  .env-name {
    font-size: 18px;
    font-weight: 600;
    color: #E8E6E3;
  }
  .rename-input {
    font-size: 18px;
    font-weight: 600;
    color: #E8E6E3;
    background: #16161E;
    border: 1px solid #98C379;
    border-radius: 6px;
    padding: 2px 8px;
    outline: none;
    font-family: inherit;
    width: 200px;
  }
  .var-count {
    font-size: 12px;
    color: #555;
    background: #1A1A24;
    padding: 2px 8px;
    border-radius: 10px;
  }
  .active-badge {
    font-size: 10px;
    color: #98C379;
    background: #98C37918;
    padding: 2px 8px;
    border-radius: 10px;
  }
  .header-actions {
    display: flex;
    gap: 6px;
  }
  .btn-action {
    padding: 5px 14px;
    border: 1px solid #2A2A38;
    border-radius: 6px;
    background: transparent;
    color: #888;
    font-family: inherit;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.15s;
  }
  .btn-action:hover {
    border-color: #555;
    color: #C8C5BE;
  }
  .btn-danger {
    color: #E06C75;
  }
  .btn-danger:hover {
    border-color: #E06C75;
    color: #E06C75;
    background: #E06C7510;
  }
  .btn-done {
    padding: 5px 16px;
    border: none;
    border-radius: 6px;
    background: #F4A623;
    color: #0C0C10;
    font-family: inherit;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.15s;
  }
  .btn-done:hover {
    background: #FFB940;
  }

  /* Env tabs */
  .env-tabs {
    display: flex;
    gap: 2px;
    border-bottom: 1px solid #1E1E28;
    margin-bottom: 16px;
    flex-wrap: wrap;
  }
  .env-tab {
    padding: 7px 14px;
    border: none;
    background: transparent;
    color: #666;
    font-family: inherit;
    font-size: 12px;
    cursor: pointer;
    border-bottom: 2px solid transparent;
    margin-bottom: -1px;
    transition: all 0.15s;
    white-space: nowrap;
  }
  .env-tab:hover { color: #999; }
  .env-tab.active {
    color: #98C379;
    border-bottom-color: #98C379;
  }

  /* Column headers */
  .col-headers {
    display: flex;
    gap: 8px;
    padding: 0 0 8px;
    border-bottom: 1px solid #1E1E28;
    margin-bottom: 8px;
  }
  .col-headers span {
    font-size: 10px;
    color: #555;
    text-transform: uppercase;
    letter-spacing: 0.8px;
  }
  .col-check { width: 18px; flex-shrink: 0; }
  .col-key { flex: 1; max-width: 220px; }
  .col-value { flex: 2; }
  .col-del { width: 28px; flex-shrink: 0; }

  /* Variable rows */
  .var-rows {
    display: flex;
    flex-direction: column;
    gap: 6px;
    flex: 1;
  }
  .var-row {
    display: flex;
    align-items: center;
    gap: 8px;
    transition: opacity 0.15s;
  }
  .var-row.disabled {
    opacity: 0.4;
  }
  .var-check {
    accent-color: #F4A623;
    flex-shrink: 0;
    cursor: pointer;
    width: 14px;
    height: 14px;
  }
  .var-key {
    flex: 1;
    max-width: 220px;
    padding: 8px 10px;
    border: 1px solid #1E1E28;
    border-radius: 6px;
    background: #111118;
    color: #E5C07B;
    font-family: inherit;
    font-size: 13px;
    outline: none;
    transition: border-color 0.15s;
  }
  .var-key:focus { border-color: #3A3A4A; }
  .var-key::placeholder { color: #333; }

  .var-value {
    flex: 2;
    padding: 8px 10px;
    border: 1px solid #1E1E28;
    border-radius: 6px;
    background: #111118;
    color: #C8C5BE;
    font-family: inherit;
    font-size: 13px;
    outline: none;
    transition: border-color 0.15s;
  }
  .var-value:focus { border-color: #3A3A4A; }
  .var-value::placeholder { color: #333; }

  .btn-remove {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border: none;
    border-radius: 6px;
    background: transparent;
    color: #444;
    font-size: 16px;
    cursor: pointer;
    flex-shrink: 0;
    transition: all 0.15s;
  }
  .btn-remove:hover {
    background: #E06C7520;
    color: #E06C75;
  }

  .btn-add-var {
    padding: 8px 14px;
    border: 1px dashed #2A2A38;
    border-radius: 6px;
    background: transparent;
    color: #555;
    font-family: inherit;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.15s;
    align-self: flex-start;
    margin-top: 4px;
  }
  .btn-add-var:hover {
    border-color: #98C379;
    color: #98C379;
  }

  /* Footer */
  .editor-footer {
    margin-top: 24px;
    padding-top: 16px;
    border-top: 1px solid #1E1E28;
    font-size: 11px;
    color: #444;
  }
  .editor-footer code {
    font-family: inherit;
    font-size: 11px;
    background: #1A1A24;
    padding: 1px 6px;
    border-radius: 4px;
    color: #888;
  }
</style>
