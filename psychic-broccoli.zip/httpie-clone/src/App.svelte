<script lang="ts">
  import TreeSidebar from './components/TreeSidebar.svelte';
  import RequestEditor from './components/RequestEditor.svelte';
  import ResponseViewer from './components/ResponseViewer.svelte';
  import EnvironmentEditor from './components/EnvironmentEditor.svelte';
  import {
    workspace, selectedLocation, currentResponse, isLoading,
    activeFile, activeRequest, activeFileVariables,
    envFile, userEnvFile, activeEnvironment, availableEnvironments,
    resolvedEnvVars, namedResults, dotenvVariables,
    updateRequestInTree, addRequestToFile, deleteRequestFromFile,
    toggleFolder, markFileSaved,
  } from './lib/stores';
  import {
    serializeHttpFile, substituteAll, parseEnvironmentFile,
    buildWorkspaceTree, createFileNode,
  } from './lib/parser';
  import type { HttpRequest, HttpResponse, SubstitutionContext, RequestLocation, EnvironmentFile } from './lib/types';

  let showEnvEditor = false;

  // ─── Tauri Imports (uncomment when Tauri plugins are installed) ───
  // import { open, save } from '@tauri-apps/plugin-dialog';
  // import { readTextFile, writeTextFile, readDir } from '@tauri-apps/plugin-fs';
  // import { fetch as tauriFetch } from '@tauri-apps/plugin-http';
  // import { dirname, join, basename, sep } from '@tauri-apps/api/path';

  // ─── Substitution Context ───

  function getSubstitutionContext(): SubstitutionContext {
    return {
      fileVariables: $activeFileVariables,
      environmentVariables: $resolvedEnvVars,
      namedResults: $namedResults,
      dotenvVariables: $dotenvVariables,
    };
  }

  // ─── Open Folder (scan for .http files) ───

  async function openFolder() {
    try {
      // ── Tauri version (uncomment when ready) ──
      // const rootPath = await open({ directory: true, title: 'Select workspace folder' });
      // if (!rootPath) return;
      //
      // const discovered = await scanForHttpFiles(rootPath as string, rootPath as string);
      // const tree = buildWorkspaceTree(discovered);
      // const rootName = await basename(rootPath as string);
      //
      // workspace.set({ rootPath: rootPath as string, rootName, tree });
      // selectedLocation.set(null);
      // currentResponse.set(null);
      // namedResults.set({});
      //
      // // Auto-discover env file from root
      // await tryLoadEnvFiles(rootPath as string);

      // ── Demo version ──
      const demoTree = buildWorkspaceTree([
        {
          absolutePath: '/demo/Customers/list.http',
          relativePath: 'Customers/list.http',
          content: [
            '@baseUrl = https://jsonplaceholder.typicode.com',
            '',
            '### List all users',
            'GET {{baseUrl}}/users',
            '',
            '### Get user by ID',
            '# @name getUser',
            'GET {{baseUrl}}/users/1',
            '',
            '### Create user',
            'POST {{baseUrl}}/users',
            'Content-Type: application/json',
            '',
            '{',
            '  "name": "Jane Doe",',
            '  "email": "jane@example.com"',
            '}',
          ].join('\n'),
        },
        {
          absolutePath: '/demo/Customers/orders.http',
          relativePath: 'Customers/orders.http',
          content: [
            '@baseUrl = https://jsonplaceholder.typicode.com',
            '',
            '### Get user todos (orders placeholder)',
            'GET {{baseUrl}}/users/1/todos',
          ].join('\n'),
        },
        {
          absolutePath: '/demo/Posts/crud.http',
          relativePath: 'Posts/crud.http',
          content: [
            '@baseUrl = https://jsonplaceholder.typicode.com',
            '',
            '### List all posts',
            'GET {{baseUrl}}/posts',
            '',
            '### Get single post',
            'GET {{baseUrl}}/posts/1',
            '',
            '### Create post',
            '# @name createPost',
            'POST {{baseUrl}}/posts',
            'Content-Type: application/json',
            '',
            '{',
            '  "title": "Hello from Psychic Broccoli",',
            '  "body": "Created via .http file!",',
            '  "userId": 1',
            '}',
            '',
            '### Delete post',
            'DELETE {{baseUrl}}/posts/1',
          ].join('\n'),
        },
        {
          absolutePath: '/demo/Posts/comments.http',
          relativePath: 'Posts/comments.http',
          content: [
            '@baseUrl = https://jsonplaceholder.typicode.com',
            '',
            '### Get comments for post 1',
            'GET {{baseUrl}}/posts/1/comments',
            '',
            '### Get all comments',
            'GET {{baseUrl}}/comments',
          ].join('\n'),
        },
        {
          absolutePath: '/demo/health.http',
          relativePath: 'health.http',
          content: [
            '### Health check',
            'GET https://jsonplaceholder.typicode.com/posts/1',
          ].join('\n'),
        },
      ]);

      workspace.set({ rootPath: '/demo', rootName: 'Preem', tree: demoTree });
      selectedLocation.set(null);
      currentResponse.set(null);
      namedResults.set({});

      // Initialize with a default "Base Environment" and demo environments
      envFile.set({
        'Base Environment': {
          baseUrl: 'https://jsonplaceholder.typicode.com',
        },
        'Development': {
          baseUrl: 'http://localhost:5000',
          token: 'dev-token-abc123',
        },
        'Staging': {
          baseUrl: 'https://staging.api.example.com',
          token: 'stg-token-xyz789',
        },
      });
      activeEnvironment.set('Base Environment');
    } catch (e) {
      console.error('Failed to open folder:', e);
    }
  }

  // ── Tauri: Recursively scan a directory for .http/.rest files ──
  // async function scanForHttpFiles(dir: string, rootDir: string): Promise<DiscoveredFile[]> {
  //   const entries = await readDir(dir);
  //   const results: DiscoveredFile[] = [];
  //
  //   for (const entry of entries) {
  //     const fullPath = await join(dir, entry.name);
  //     if (entry.isDirectory) {
  //       results.push(...await scanForHttpFiles(fullPath, rootDir));
  //     } else if (entry.name.endsWith('.http') || entry.name.endsWith('.rest')) {
  //       const content = await readTextFile(fullPath);
  //       const relativePath = fullPath.replace(rootDir + sep, '').replaceAll(sep, '/');
  //       results.push({ absolutePath: fullPath, relativePath, content });
  //     }
  //   }
  //   return results;
  // }

  // ── Tauri: Auto-discover env files from workspace root ──
  // async function tryLoadEnvFiles(rootDir: string) {
  //   try {
  //     const envPath = await join(rootDir, 'http-client.env.json');
  //     const content = await readTextFile(envPath);
  //     const parsed = parseEnvironmentFile(content);
  //     if (parsed) {
  //       envFile.set(parsed);
  //       const names = Object.keys(parsed).filter(k => k !== '$shared');
  //       if (names.length > 0 && !$activeEnvironment) activeEnvironment.set(names[0]);
  //     }
  //   } catch { /* file doesn't exist */ }
  //
  //   try {
  //     const userPath = await join(rootDir, 'http-client.env.json.user');
  //     const content = await readTextFile(userPath);
  //     const parsed = parseEnvironmentFile(content);
  //     if (parsed) userEnvFile.set(parsed);
  //   } catch { /* file doesn't exist */ }
  // }

  // ─── Save File ───

  import { getAllFileNodes } from './lib/parser';

  function findFileInTree(nodes: any[], path: string): any {
    for (const n of nodes) {
      if (n.type === 'file' && n.path === path) return n;
      if (n.type === 'folder') { const f = findFileInTree(n.children, path); if (f) return f; }
    }
    return null;
  }

  async function saveActiveFile() {
    const file = $activeFile;
    if (!file || !file.dirty) return;

    try {
      const content = serializeHttpFile(file.requests, file.variables);

      // ── Tauri version ──
      // await writeTextFile(file.path, content);

      // ── Demo version ──
      console.log(`[save] ${file.name}`, content);

      markFileSaved(file.path);
    } catch (e) {
      console.error(`Failed to save:`, e);
    }
  }

  // ─── Send Request ───

  async function sendRequest(request: HttpRequest) {
    isLoading.set(true);
    currentResponse.set(null);

    const ctx = getSubstitutionContext();
    const startTime = performance.now();

    try {
      const url = substituteAll(request.url, ctx);
      const body = substituteAll(request.body, ctx);
      const headers: Record<string, string> = {};
      for (const h of request.headers) {
        if (h.enabled) {
          headers[substituteAll(h.key, ctx)] = substituteAll(h.value, ctx);
        }
      }

      // ── Tauri version ──
      // const res = await tauriFetch(url, { method: request.method, headers,
      //   body: ['GET','HEAD','OPTIONS'].includes(request.method) ? undefined
      //     : { type: 'Text', payload: body } });
      // const resBody = await res.text();

      // ── Demo version ──
      const res = await fetch(url, {
        method: request.method, headers,
        body: ['GET','HEAD','OPTIONS'].includes(request.method) ? undefined : body || undefined,
      });
      const resBody = await res.text();

      const elapsed = performance.now() - startTime;
      const resHeaders: Record<string, string> = {};
      res.headers.forEach((v: string, k: string) => { resHeaders[k] = v; });

      const response: HttpResponse = {
        status: res.status, statusText: res.statusText,
        headers: resHeaders, body: resBody,
        time: Math.round(elapsed), size: new Blob([resBody]).size,
      };
      currentResponse.set(response);

      if (request.varName) {
        namedResults.update(nr => ({
          ...nr,
          [request.varName!]: {
            request: { url, method: request.method, headers, body },
            response,
          },
        }));
      }
    } catch (e: any) {
      currentResponse.set({
        status: 0, statusText: 'Error', headers: {},
        body: e.message || 'Request failed.', time: Math.round(performance.now() - startTime), size: 0,
      });
    } finally {
      isLoading.set(false);
    }
  }

  // ─── Event Handlers ───

  function handleSelect(e: CustomEvent<RequestLocation>) {
    selectedLocation.set(e.detail);
    currentResponse.set(null);
  }

  function handleUpdateRequest(e: CustomEvent<HttpRequest>) {
    if (!$selectedLocation) return;
    updateRequestInTree($selectedLocation.filePath, $selectedLocation.requestIndex, e.detail);
  }

  function handleAddRequest(e: CustomEvent<string>) {
    addRequestToFile(e.detail);
  }

  function handleDeleteRequest(e: CustomEvent<{ filePath: string; requestIndex: number }>) {
    deleteRequestFromFile(e.detail.filePath, e.detail.requestIndex);
  }

  function handleToggleFolder(e: CustomEvent<string>) {
    toggleFolder(e.detail);
  }

  function handleAddEnv(e: CustomEvent<string>) {
    const name = e.detail;
    envFile.update(ef => {
      const current = ef ?? {};
      return { ...current, [name]: {} };
    });
    activeEnvironment.set(name);
  }

  async function handleRunAll(e: CustomEvent<string[]>) {
    const depNames = e.detail;
    // Find and send each dependency in order
    const allFiles = getAllFileNodes($workspace.tree);
    for (const name of depNames) {
      if ($namedResults[name]) continue; // Already sent
      // Find the request with this varName
      for (const file of allFiles) {
        const req = file.requests.find(r => r.varName === name);
        if (req) {
          await sendRequest(req);
          break;
        }
      }
    }
  }

  function handleNameRequest(e: CustomEvent<{ filePath: string; requestIndex: number; varName: string }>) {
    const { filePath, requestIndex, varName } = e.detail;
    const file = findFileInTree($workspace.tree, filePath);
    if (!file) return;
    const req = file.requests[requestIndex];
    if (!req) return;
    updateRequestInTree(filePath, requestIndex, { ...req, varName: varName || null });
  }

  // Auto-open the demo folder on mount
  import { onMount } from 'svelte';
  onMount(() => {
    openFolder();
  });
</script>

<main class="app">
  <div class="titlebar" data-tauri-drag-region>
    <div class="titlebar-left">
      <span class="app-icon">🥦</span>
      <span class="app-name">Psychic Broccoli</span>
      {#if $activeFile}
        <span class="file-name">{$activeFile.name}</span>
      {/if}
    </div>
  </div>

  <div class="layout">
    <div class="sidebar-container">
      <TreeSidebar
        tree={$workspace.tree}
        selected={$selectedLocation}
        rootName={$workspace.rootName}
        environments={$availableEnvironments}
        activeEnv={$activeEnvironment}
        on:openFolder={openFolder}
        on:select={handleSelect}
        on:toggleFolder={handleToggleFolder}
        on:addRequest={handleAddRequest}
        on:deleteRequest={handleDeleteRequest}
        on:changeEnv={(e) => activeEnvironment.set(e.detail)}
        on:addEnv={handleAddEnv}
        on:editEnv={() => showEnvEditor = true}
        on:nameRequest={handleNameRequest}
      />
    </div>

    <div class="main-panels">
      {#if showEnvEditor && $envFile && $activeEnvironment}
        <div class="env-editor-pane">
          <EnvironmentEditor
            envFile={$envFile}
            activeEnv={$activeEnvironment}
            on:update={(e) => {
              envFile.set(e.detail);
              // Tauri: auto-save to http-client.env.json
              // const content = JSON.stringify(e.detail, null, 2);
              // writeTextFile(join($workspace.rootPath, 'http-client.env.json'), content);
            }}
            on:changeEnv={(e) => activeEnvironment.set(e.detail)}
            on:close={() => showEnvEditor = false}
          />
        </div>
      {:else if $activeRequest && $selectedLocation}
        <div class="editor-pane">
          <RequestEditor
            request={$activeRequest}
            loading={$isLoading}
            dirty={$activeFile?.dirty ?? false}
            resolvedUrl={$activeRequest.url.includes('{{') ? substituteAll($activeRequest.url, getSubstitutionContext()) : ''}
            fileVariables={$activeFileVariables}
            envVariables={$resolvedEnvVars}
            namedResults={$namedResults}
            on:update={handleUpdateRequest}
            on:send={(e) => sendRequest(e.detail)}
            on:save={saveActiveFile}
            on:runAll={handleRunAll}
          />
        </div>
        <div class="response-pane">
          <ResponseViewer response={$currentResponse} loading={$isLoading} />
        </div>
      {:else}
        <div class="no-selection">
          <span class="no-sel-icon">↗</span>
          <span class="no-sel-text">Select a request from the sidebar</span>
        </div>
      {/if}
    </div>
  </div>
</main>

<style>
  :global(*) {
    margin: 0; padding: 0; box-sizing: border-box;
  }
  :global(body) {
    font-family: 'SF Mono', 'Cascadia Code', 'JetBrains Mono', 'Fira Code', monospace;
    background: #0C0C10; color: #C8C5BE;
    overflow: hidden; font-size: 13px;
  }

  .app {
    display: flex; flex-direction: column;
    height: 100vh; background: #0C0C10;
  }

  .titlebar {
    display: flex; justify-content: space-between; align-items: center;
    height: 44px; padding: 0 16px;
    background: #111116; border-bottom: 1px solid #1E1E28;
    -webkit-app-region: drag; user-select: none; flex-shrink: 0;
  }
  .titlebar-left { display: flex; align-items: center; gap: 10px; min-width: 0; }
  .app-icon { font-size: 16px; }
  .app-name { font-weight: 700; font-size: 14px; color: #F4A623; letter-spacing: -0.3px; }
  .file-name { font-size: 12px; color: #666; }
  .layout { display: flex; flex: 1; overflow: hidden; }

  .sidebar-container {
    display: flex; flex-direction: column;
    width: 260px; min-width: 260px;
    background: #111116; border-right: 1px solid #1E1E28;
    flex-shrink: 0; overflow: hidden;
  }

  .main-panels { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
  .editor-pane { flex: 1; overflow: auto; }
  .response-pane { flex: 1; overflow: auto; border-left: 1px solid #1E1E28; }
  .env-editor-pane { flex: 1; overflow: auto; }

  .no-selection {
    flex: 1; display: flex; flex-direction: column;
    align-items: center; justify-content: center; gap: 12px;
  }
  .no-sel-icon { font-size: 48px; opacity: 0.15; }
  .no-sel-text { font-size: 14px; color: #444; }
</style>
